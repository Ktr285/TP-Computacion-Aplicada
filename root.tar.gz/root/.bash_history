shutdown now
hostnamectl set-home TPServer
hostnamectl set-homename TPServer
hostnamectl set-hostname TPServer
hostnamectl
cat /etc/apt/sources.list
lsb_release -a
poweroff
lsb_release -a
ping -c 4 deb.debian.org
apt update
apt upgrade
apt full-upgrade
cp /etc/apt/sources.list /etc/apt/sources.list.bak
nano /etc/apt/sources.list
cp /etc
/
cp /etc/apt/sources.list.bak /etc/apt/sources.list
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
cat /etc/apt/sources.list
cat /etc/apt/sources.ist
cat /etc/apt/sources.list
sed -i 's/ main$/ main contrib non-free non-free-firmware/' /etc/apt/sources.list
cat /etc/apt/sources.list
nano /etc/apt/sources.list
apt-update
apt update
apt updgrade --without-new-pkgs
apt upgrade --without-new-pkgs
q
fg
apt full-upgrade
reboot
lsb_release -a
systemctl status ssh
hostname -I
mkdir -p /root/.ssh
chmod 700 /root/.ssh
ls -ld /root/.ssh
sshd -T | grep permitrootlogin
wget -O /root/.ssh/authorized_keys https://192.168.0.7:8765/clave_publica.pub
wget -O /root/.ssh/authorized_keys http://192.168.0.7:8765/clave_publica-.pub
wget -O /root/.ssh/authorized_keys http://192.168.0.7:8765/clave_publica.pub
chmod 600 /root/.ssh/authorized_keys
ls -l /root/.ssh/authorized_keys
cat /var/lib/dhcp/dhclient*.leases
nano /etc/network/interfaces
cat /etc/network/interfaces
systemctl restart networking
ip -br addr
ip route
ping -c 4 192.168.0.1
ping -c 4 debian.org
lsblk
shutdown -h now
apt update
apt install apache2 php libapache2-mod-php
systemctl status apache2
http://192.168.0.21
mv /var/www/html/index.html /var/www/html/index.html.bak
systemctl restart apache2
apt install mariadb-server mariadb-client php-mysql
systemctl status mariadb
ls -l /root/index.php
cp /root/index.php /var/www/html/
ls -l /var/www/html/
mariadb -e "source /root/db.sql"
mariadb -e "SHOW DATABASES;"
mariadb -e "SHOW TABLES FROM ingenieria;"
tail -n 15 /var/log/apache2/error.log
systemctl restart apache2
php -m | grep -i mysqli
ip -br addr
ip route
cat /etc/network/interfaces
cat /etc/resolv.conf
ls /etc/network/interfaces.d/
cp /etc/network/interfaces /etc/network/interfaces.bak
ls -l /etc/network/interfaces*
ipconfig /all
lsblk
fdisk /dev/sdb
lsblk
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
mkdir /www_dir
mkdir /backup_dir
ls -ld /www_dir /backup_dir
mount /dev/sdb1 /www_dir
df -h /www_dir
mount /dev/sdb2 /backup_dir
df -h /backup_dir
cp /etc/fstab /etc/fstab.bak
blkid /dev/sdb1 /dev/sdb2
nano /etc/fstab
findmnt --verify
systemctl daemon-reload
findmnt --verify
lsblk -f
reboot
lsblk -f
systemctl is-active apache2 mariadb ssh
ls -lah /var/www/html/
ls -lah /www_dir/
cp /var/www/html/index.php /www_dir/
ls -lh /www_dir/
tar -czvf /backup_dir/sitio_backup.tar.gz -C /var/www/html
tar -czvf /backup_dir/sitio_backup.tar.gz -C /var/www/html .
ls -lh /backup_dir/
tar -tzvf /backup_dir/sitio_backup.tar.gz
cat /etc/apache2/sites-available/000-default.conf
cp /etc/apache32/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
ls -l /etc/apache2/sites-available/
nano /etc/apache2/sites-available/000-default.conf
sed -i '/<\/VirtualHost>/i\    <Directory /www_dir>\n        Options FollowSymLinks\n        AllowOverride None\n        Require all granted\n    </Directory>' /etc/apache2/sites-available/000-default.conf
apache2ctl configtest
Syntax OK
grep -A 6 'DocumentRoot\|<Directory /www_dir>' /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
systemctl is-active apache2
df -h /www_dir /backup_dir
reboot
ls -la /opt/scripts/
ls -la /opt/scripts/
mkdir -p /opt/scripts
ls -ld /opt/scripts
nano /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh --help
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -lh /backup_dir/
systemctl is-active cron
crontab -e
crontab -l
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir/
mkdir -p /root/TP-Computacion-Aplicada
cp /www_dir/index.php /opt/scripts/backup_full.sh /root/TP-Computacion-Aplicada/
ls -lh /root/TP-Computacion-Aplicada/
cp /etc/apache2/sites-available/000-default.conf /root/TP-Computacion-Aplicada/apache.conf
crontab -l > /root/TP-Computacion-Aplicada/cron.txt
ls -lh /root/TP-Computacion-Aplicada/
find /root /home -type f -name "*.sql" 2>/dev/null
cp /root/db.sql /root/TP-Computacion-Aplicada/
ls -lh /root/TP-Computacion-Aplicada/
grep -nEi 'mysqli|PDO|password|passwd' /root/TP-Computacion-Aplicada/index.php | cut -d: -f1
nano /root/TP-Computacion-Aplicada/index.php
nano /root/TP-Computacion-Aplicada/README.md
sed -i 's/ServerAdmin webmaster@localhost/ServerAdmin julianrallo02@gmail.com/' /root/TP-Computacion-Aplicada/apache.conf
ls -lh /root/TP-Computacion-Aplicada/
grep -n 'CAMBIAR_PASSWORD' /root/TP-Computacion-Aplicada/index.php
php -l /root/TP-Computacion-Aplicada/index.php
exit
